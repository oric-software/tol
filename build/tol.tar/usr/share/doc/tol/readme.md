
Wave200.dsk contains TOL music from Twilighte in Wave software

= Telemon version =
* Storybook works only

= TODO = 
* Game 
* title
* ctrl + c and esc for storybook, game and title

